#!/bin/bash

before_reboot(){
  #This install making for ur linux bundle of special programm
  USER=$(logname)
  DIR1=$USER
  echo "HI WELCOME TO MNSINSTALL"
  echo "WAIT WE WILL CREATE SPECIAL CONDITION TO REBOOTING"
  cd scripts
  echo "Please wait while install from 5 to 10 min"
  cd .. && echo "DONE"	
  cd /home/$DIR1/mnsinstall/scripts
  chmod +x driverinstall && ./driverinstall
}

after_reboot(){
  USER=$(logname)
  
  cd /home
  cd $USER
  cd /mnsinstall
  mkdir tar run && cd scripts
  echo "Please wait while install from 5 to 10 min"
  cd /home/$DIR1/mnsinstall/scripts
  ./preinstall
  echo "Pre install actions completed"
  ./packdebinstall
  echo "debian package install completed"
  ./packruninstall
  echo "Runnable app install completed"
  ./packtarinstall
  echo "Tar archives install completed"
  ./postinstall
  echo "Post install completed"
}

if [ -f /home/$USER/mnsinstall/install.sh ]; then
    after_reboot
    rm /var/run/rebooting-for-updates
    update-rc.d myupdate remove
else
    before_reboot
    USER=$(logname)
    DIR1=$USER
    touch /var/run/rebooting-for-updates && touch /etc/init.d/myupdate
    cp -ivR /home/$DIR1/mnsinstall/install.sh /var/run/rebooting-for-updates
    chmod +x /var/run/rebooting-for-updates
    cp -ivR myupdate /etc/init.d/ && chmod +x /etc/init.d/myupdate
    update-rc.d myupdate defaults
    
fi

